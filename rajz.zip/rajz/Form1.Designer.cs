namespace rajz
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.pontszam = new System.Windows.Forms.NumericUpDown();
			this.button1 = new System.Windows.Forms.Button();
			this.X = new System.Windows.Forms.NumericUpDown();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.Y = new System.Windows.Forms.NumericUpDown();
			this.R = new System.Windows.Forms.NumericUpDown();
			((System.ComponentModel.ISupportInitialize)(this.pontszam)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.X)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.Y)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.R)).BeginInit();
			this.SuspendLayout();
			// 
			// pontszam
			// 
			this.pontszam.Location = new System.Drawing.Point(482, 9);
			this.pontszam.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
			this.pontszam.Minimum = new decimal(new int[] {
            4,
            0,
            0,
            0});
			this.pontszam.Name = "pontszam";
			this.pontszam.Size = new System.Drawing.Size(51, 20);
			this.pontszam.TabIndex = 0;
			this.pontszam.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.SystemColors.Control;
			this.button1.Location = new System.Drawing.Point(548, 9);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 1;
			this.button1.Text = "�jrarajzol";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.onUjrarajzol);
			// 
			// X
			// 
			this.X.Location = new System.Drawing.Point(89, 7);
			this.X.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
			this.X.Name = "X";
			this.X.Size = new System.Drawing.Size(54, 20);
			this.X.TabIndex = 2;
			this.X.Value = new decimal(new int[] {
            300,
            0,
            0,
            0});
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(71, 13);
			this.label1.TabIndex = 3;
			this.label1.Text = "K�z�ppont X:";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(149, 9);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(71, 13);
			this.label2.TabIndex = 4;
			this.label2.Text = "K�z�ppont Y:";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(286, 9);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(38, 13);
			this.label3.TabIndex = 5;
			this.label3.Text = "Sug�r:";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(390, 9);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(86, 13);
			this.label4.TabIndex = 6;
			this.label4.Text = "Pontsz�m (4-50):";
			// 
			// Y
			// 
			this.Y.Location = new System.Drawing.Point(226, 9);
			this.Y.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
			this.Y.Name = "Y";
			this.Y.Size = new System.Drawing.Size(54, 20);
			this.Y.TabIndex = 7;
			this.Y.Value = new decimal(new int[] {
            300,
            0,
            0,
            0});
			// 
			// R
			// 
			this.R.Location = new System.Drawing.Point(330, 9);
			this.R.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
			this.R.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
			this.R.Name = "R";
			this.R.Size = new System.Drawing.Size(54, 20);
			this.R.TabIndex = 8;
			this.R.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.ForestGreen;
			this.ClientSize = new System.Drawing.Size(750, 525);
			this.Controls.Add(this.R);
			this.Controls.Add(this.Y);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.X);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.pontszam);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.rajzol);
			((System.ComponentModel.ISupportInitialize)(this.pontszam)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.X)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.Y)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.R)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown pontszam;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.NumericUpDown X;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown Y;
		private System.Windows.Forms.NumericUpDown R;
    }
}

