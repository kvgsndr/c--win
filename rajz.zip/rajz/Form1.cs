using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace rajz
{
    public partial class Form1 : Form
    {
        public Single korx(Single x, Single y, Single r, Single fok)
        {
            return (Single)(Math.Cos(((Single)(90 - fok)) * Math.PI / 180) * r + x);
        }
        public Single kory(Single x, Single y, Single r, Single fok)
        {
            return (Single)(y - Math.Sin(((Single)(90 - fok)) * Math.PI / 180) * r);
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void rajzol(object sender, PaintEventArgs e)
        {
            Pen toll = new Pen(Color.Aqua,1);
            Single x , y, r;
            Single x1, y1, x2,y2;
            x = (Single)X.Value;
            y = (Single)Y.Value;
            r = (Single)R.Value;
            e.Graphics.DrawEllipse(toll, x - r, y - r, 2 * r, 2 * r);
            for (Single p1 = 0; p1 < 360; p1 += (360 / (Single)pontszam.Value))
            {
                x1 = korx(x, y, r, p1);
                y1 = kory(x, y, r, p1);
                for (Single p2 = p1; p2 < 360; p2 += (360 / (Single)pontszam.Value))
                {
                    x2 = korx(x, y, r, p2);
                    y2 = kory(x, y, r, p2);
                        e.Graphics.DrawLine(toll, x1, y1, x2, y2);
                }
            }
        }

        private void onUjrarajzol(object sender, EventArgs e)
        {
            Invalidate();
			Update();
        }

  
    }
}