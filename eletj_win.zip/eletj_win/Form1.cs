﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace eletj_win
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            van = false;
        }
        const int XMAX = 1000;
        const int YMAX = 700;
        private bool van;
        private char [,]t = new char[XMAX+2,YMAX+2];
        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string fn;
                for (int x = 0; x < XMAX+2; x++)
                    for (int y = 0; y < YMAX+2; y++)
                        t[x, y] = ' ';
                StreamReader o = new StreamReader(openFileDialog1.FileName);
                while (!o.EndOfStream)
                {
                    fn = o.ReadLine();
                    string[] s = fn.Split(',');
                    t[Convert.ToInt32(s[0]), Convert.ToInt32(s[1])] = 'O';
                }
                o.Close();
                van = true;
                Invalidate();
                Update();
            }
        }

        Brush br = new SolidBrush(Color.Blue);
        private void onPaint(object sender, PaintEventArgs e)
        {
            if (van)
            {
                e.Graphics.Clear(Color.White);
                for (int y = 1; y <= YMAX; y++)
                    for (int x = 1; x <= XMAX; x++)
                        if (t[x,y] == 'O')
                            e.Graphics.FillRectangle(br, x, y, 1, 1);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            lepj();
        }

        private void lepj()
        {
            int szdb;
            char[,] st = new char[XMAX + 2, YMAX + 2]; 
            for (int y = 1; y <= YMAX; y++)
                for (int x = 1; x <= XMAX; x++)
                {
                    szdb = 0;
                    for (int dx = x - 1; dx <= x + 1; dx++)
                        for (int dy = y - 1; dy <= y + 1; dy++)
                            if (t[dx, dy] == 'O')
                                szdb++;
                    if (t[x, y] == 'O')
                        if ((szdb == 3) || (szdb == 4))
                            st[x, y] = 'O';
                        else
                            st[x, y] = ' ';
                    else
                        if (szdb == 3)
                            st[x, y] = 'O';
                        else
                            st[x, y] = ' ';
                }
            for (int y = 1; y <= YMAX; y++)
                for (int x = 1; x <= XMAX; x++)
                    t[x, y] = st[x, y];
            Invalidate();
            Update();
        }

        private void onTick(object sender, EventArgs e)
        {
            if (van && checkBox1.Checked)
                lepj();
        }
    }
}
