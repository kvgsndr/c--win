namespace prb1
{
    partial class Proba
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.eredeti = new System.Windows.Forms.TextBox();
            this.masolat = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.baljobb = new System.Windows.Forms.CheckBox();
            this.kep = new System.Windows.Forms.PictureBox();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.kep)).BeginInit();
            this.SuspendLayout();
            // 
            // eredeti
            // 
            this.eredeti.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.eredeti.Location = new System.Drawing.Point(31, 21);
            this.eredeti.Name = "eredeti";
            this.eredeti.Size = new System.Drawing.Size(276, 26);
            this.eredeti.TabIndex = 0;
            // 
            // masolat
            // 
            this.masolat.Location = new System.Drawing.Point(366, 21);
            this.masolat.Name = "masolat";
            this.masolat.Size = new System.Drawing.Size(335, 20);
            this.masolat.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.button1.Location = new System.Drawing.Point(301, 58);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 51);
            this.button1.TabIndex = 2;
            this.button1.Text = "M�sol";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.onMasol);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(301, 136);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 3;
            this.button2.Text = "T�r�l";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.onTorol);
            // 
            // baljobb
            // 
            this.baljobb.AutoSize = true;
            this.baljobb.Location = new System.Drawing.Point(115, 92);
            this.baljobb.Name = "baljobb";
            this.baljobb.Size = new System.Drawing.Size(84, 17);
            this.baljobb.TabIndex = 4;
            this.baljobb.Text = "Balr�l jobbra";
            this.baljobb.UseVisualStyleBackColor = true;
            // 
            // kep
            // 
            this.kep.Location = new System.Drawing.Point(398, 58);
            this.kep.Name = "kep";
            this.kep.Size = new System.Drawing.Size(303, 219);
            this.kep.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.kep.TabIndex = 5;
            this.kep.TabStop = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(273, 183);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 6;
            this.button3.Text = "K�p";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.onKep);
            // 
            // Proba
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(770, 305);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.kep);
            this.Controls.Add(this.baljobb);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.masolat);
            this.Controls.Add(this.eredeti);
            this.Name = "Proba";
            this.Text = "Pr�ba winvacak";
            ((System.ComponentModel.ISupportInitialize)(this.kep)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox eredeti;
        private System.Windows.Forms.TextBox masolat;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox baljobb;
        private System.Windows.Forms.PictureBox kep;
        private System.Windows.Forms.Button button3;
    }
}

