using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace prb1
{
    public partial class Proba : Form
    {
        public Proba()
        {
            InitializeComponent();
        }

        private void onMasol(object sender, EventArgs e)
        {
            if (baljobb.Checked)
                masolat.Text = eredeti.Text;
            else
                eredeti.Text = masolat.Text;
        }

        private void onTorol(object sender, EventArgs e)
        {
            eredeti.Text = "";
            masolat.Text = "";
        }

        private void onKep(object sender, EventArgs e)
        {
            OpenFileDialog f = new OpenFileDialog();
            f.ShowDialog();
            kep.Load(f.FileName);
        }
    }
}