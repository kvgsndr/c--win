namespace pattog
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.patte = new System.Windows.Forms.CheckBox();
			this.meret = new System.Windows.Forms.NumericUpDown();
			this.sebb = new System.Windows.Forms.NumericUpDown();
			this.vastag = new System.Windows.Forms.NumericUpDown();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.meret)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.sebb)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.vastag)).BeginInit();
			this.SuspendLayout();
			// 
			// patte
			// 
			this.patte.AutoSize = true;
			this.patte.Location = new System.Drawing.Point(12, 24);
			this.patte.Name = "patte";
			this.patte.Size = new System.Drawing.Size(80, 17);
			this.patte.TabIndex = 0;
			this.patte.Text = "Pattogjon ?";
			this.patte.UseVisualStyleBackColor = true;
			// 
			// meret
			// 
			this.meret.Location = new System.Drawing.Point(98, 21);
			this.meret.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.meret.Name = "meret";
			this.meret.Size = new System.Drawing.Size(54, 20);
			this.meret.TabIndex = 1;
			this.meret.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			// 
			// sebb
			// 
			this.sebb.Location = new System.Drawing.Point(160, 21);
			this.sebb.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
			this.sebb.Name = "sebb";
			this.sebb.Size = new System.Drawing.Size(59, 20);
			this.sebb.TabIndex = 2;
			this.sebb.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			// 
			// vastag
			// 
			this.vastag.Location = new System.Drawing.Point(225, 21);
			this.vastag.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.vastag.Name = "vastag";
			this.vastag.Size = new System.Drawing.Size(55, 20);
			this.vastag.TabIndex = 3;
			this.vastag.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(167, 5);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(52, 13);
			this.label1.TabIndex = 4;
			this.label1.Text = "sebess�g";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(235, 5);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(33, 13);
			this.label2.TabIndex = 5;
			this.label2.Text = "vonal";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(108, 5);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(33, 13);
			this.label3.TabIndex = 6;
			this.label3.Text = "m�ret";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(493, 409);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.vastag);
			this.Controls.Add(this.sebb);
			this.Controls.Add(this.meret);
			this.Controls.Add(this.patte);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.rajzol);
			((System.ComponentModel.ISupportInitialize)(this.meret)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.sebb)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.vastag)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox patte;
        private System.Windows.Forms.NumericUpDown meret;
        private System.Windows.Forms.NumericUpDown sebb;
        private System.Windows.Forms.NumericUpDown vastag;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

