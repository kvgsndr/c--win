using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace pattog
{
    public partial class Form1 : Form
    {
        System.Windows.Forms.Timer ido = new System.Windows.Forms.Timer();
        int x = 0;
        int seb = 1;

        void idokezelo(Object o, EventArgs e)
        {
            if (patte.Checked)
            {
                x += seb*(int)sebb.Value;
                if (x >= ClientRectangle.Width - (int)meret.Value)
                    seb = 0 - seb;
                if (x <= 0)
                    seb = 0 - seb;
				Rectangle r = new Rectangle(0, 200 - (int)vastag.Value, ClientRectangle.Width, (int)meret.Value * 3);
                Invalidate(r,false);
                Update();
            }
        }

        public Form1()
        {
            InitializeComponent();
            ido.Interval = 10;
            ido.Tick += new EventHandler(idokezelo);
            ido.Start();
        }

        private void rajzol(object sender, PaintEventArgs e)
        {
            Pen toll = new Pen(Color.Blue,(int)vastag.Value);
            e.Graphics.DrawEllipse(toll, x, 200, (int)meret.Value, (int)meret.Value);
        }
    }
}
